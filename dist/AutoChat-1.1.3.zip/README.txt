AutoChat / 自动聊天  v1.1.3 candidate  —— SETTINGS + PLAYER TEMPLATES + ADDON API

English
-------
Sends a squad chat line WITHOUT opening the chat box, so your keyboard and mouse
are never taken away for sending. Press K in game to open the settings panel.

Why a chat can be sent without the chat box: the box seizes the keyboard and
mouse, draws itself, collects keys, and THEN calls the send function. Being stuck
in the chat box is the first two steps. This mod needs only the last one -- the
same chat object and the same sender the box itself uses -- so there is no box and
no input lock.

Before anything is sent, five machine-code signatures are checked against the
running game.dll. If any does not match, the mod goes dormant and says which one
changed: an unverified address is an arbitrary address.

Panel redraw signatures cache their raw values and rebuild only when displayed
content changes. Ping and stratagem events rejected only for transient readiness
or queue capacity are retried while their native marker remains valid; accepted
messages are never evicted to make room. Plugin event notifications are sent once.

Custom alert rules and Unicode input (0.8.3)
Settings > Ping > Stratagem rules / Enemy rules opens the dedicated editors.
Each stratagem has an enable switch, separate mark/call templates and cooldown.
Blank messages inherit defaults; blank cooldown uses the global player timer.
Explicit rule cooldown is independent per trigger player + rule; 0 bypasses
global cooldown and prioritizes new events, while master/dedup still apply.
No zero-cooldown rules are seeded; configure individual rules when needed.
Native names/icon materials/stable IDs follow the workspace StratagemCooldown
reader. Search/filter and red/blue/green bulk enable/disable are available.
On the English UI, built-in Chinese presets stay hidden; Chinese custom text uses
an English display placeholder in the panel and plugin canvas. This changes only
what is drawn: saved values, edit buffers and outgoing UTF-8 messages are untouched.
The Chinese UI continues to display Chinese values.
Icons draw only when the game's material is already loaded. Same-name variants
with the same call type share one GUI rule (resupply/reward and jump packs).
Actual event variant IDs remain unknown when ambiguous. Unresolved identities
that cannot select even a shared rule retain the default templates/cooldown.
Enemy groups: Small / Medium / Large / Massive, plus independent Flying.
Small defaults off. Flight wins over size. Reviewed current catalog covers 142
spottable hostile resources (12 flying), not a guarantee for future game builds.
Native new stratagem rows auto-appear on a supported layout; unknown groups use
Other. New enemy facts and changed binaries require verification/update.
The catalog editor displays validated Simplified Chinese names for the current
149 stratagem rows and falls back to internal English debug names for unknown IDs.
Scanning never calls native localization in bulk. Event messages prefer the
event-time localized name, then the mapped display name. In-game IME input is
handled through queued window-thread messages; physical in-game entry still needs
verification for this candidate.
One user-sampled Super Earth cache resource uses the exact-hash fallback label "坠落舱" when its native name is generic; this is not official localization and does not cover other cache resources. The tower-top marker follows its existing path; the user confirmed the tower-base generic point should remain unsupported.
中文：设置→标记消息→战备细分设置 / 敌人体型与飞行提醒。
空消息沿用默认；冷却留空使用全局，独立秒数按触发者+规则计时，0绕过全局。
默认不预置零冷却规则；需要时可逐项配置。
战备可搜索、逐项开关、分别设置召唤/落地标记模板，红蓝绿一键开关。
图标只显示游戏已加载材质；同名且呼叫方式一致的奖励等变体共用规则。
界面语言按游戏设置切换；战备消息名称按预设的消息语言选择，与界面语言相互独立。当前稳定目录149个战备ID具有双语映射，未核实名称使用通用可读fallback；未知运行时ID的消息不暴露内部代码。扫描不批量调用游戏本地化函数。六种已核实的SEAF炮弹走现有任务建筑提醒。一个经用户实机样本核对的Super Earth cache资源在泛名称时回退显示“坠落舱”；这不是官方本地化，也不覆盖其他cache资源。广播塔顶端标记沿用既有路径；用户确认塔底泛型点不需适配。游戏内IME输入仍待实机验收。
不能确定具体变体时不冒认ID；连同名规则也无法确定时使用默认提醒。
飞行优先于体型；小型默认关闭；当前142条可标记敌对资源，12条飞行。
新增战备在兼容布局下自动发现；新敌人及游戏二进制更新仍需校验。

Role presets and private output (0.8.3)
---------------------------------------
HOST PRESET / CLIENT PRESET select what you EDIT. The current session role selects
what RUNS. Welcome, ping categories, templates, cooldown, output and tasks are separate.
Old settings/tasks remain with host. Client copies old ping preferences, disables
welcome and defaults to ONLY ME. Host keeps its saved welcome choice (off on a fresh install).
AUTO MESSAGES > SQUAD CHAT / ONLY ME selects output for all automatic messages and
registered addon sends. ONLY ME calls native chat add-line without a network send;
other players do not receive it. It retains normal chat name formatting.
An unknown role waits; local signature failure never falls back to public chat.
Role changes clear old welcome/ping queues and cooldown. Deadlines continue while
another role is active. Presets and tasks have no fixed entry-count cap; local
storage remains bounded by the documented per-file and per-preset size limits.
Named preset v5 files save task definitions, all behavior settings and optional
opaque addon preset data.
Older presets without task definitions preserve the destination role's current
tasks. Old quick-timer values are read only for one-time conversion to ordinary
repeat tasks; there is no separate quick-timer sender or settings page.
Manual console send/force remain explicit squad sends. New native local display
requires an in-game check; offline tests do not establish multiplayer visibility.

The panel hotkey defaults to K when Mod Bindings Menu is unavailable. When that
menu is ready, AutoChat registers a rebindable "Toggle AutoChat panel" action under
Mods > AutoChat. Assign its key on the bindings page; the registered action then
replaces K. The menu persists the assigned key with its native game settings.
The menu API has no default-key setter, so a new menu registration starts unbound.
After rebinding, verify in game that the new key both opens and closes the panel;
offline tests cannot confirm that the game keeps refreshing this action while
AutoChat's raw keyboard input lock is active.

The panel (hotkey K or Mod Bindings Menu action)
--------------------
  - Armory Forge's 1000x990 frame, shield, title strip, tabs and two-column layout
  - uses verified loaded game fonts; readable sizes and higher text contrast
  - long labels are truncated instead of shrinking text to 6 pixels
  - while it is open the mouse is released so you can click; on close the cursor
    and the clip rectangle are restored exactly as they were
  - game keyboard/mouse input is blocked while open (including ESC and O);
    raw registrations are restored on close, focus loss, errors and shutdown
  - drag the top strip to move; CTRL +/- scales; CTRL+0 resets position and scale
  - buttons activate on release inside the same control, as in Armory
  - SETTINGS: event name, schedule mode, custom time and message fields
  - repeat every N seconds / countdown once / daily HH:MM (local system clock)
  - click fields to type, including Windows IME; ENTER confirms, ESC cancels,
    CTRL+V pastes Unicode. The 0.8.3 IME path has offline native tests; in-game
    physical input remains unverified.
  - click ADD TASK to save tasks; the task file has a 16 MiB size limit

Timed send
----------
Role-specific tasks run while the game is running, using real elapsed time
independent of FPS. Scheduled tasks keep the selected local/squad output and
normal send cooldown.
Repeat/countdown accept 5-86400 seconds. Daily tasks run at most once per local day.
Countdown deadlines persist across restarts; overdue tasks attempt once on launch.
Unavailable chat, unknown role and cooldown leave tasks pending with a reason.
An enabled pre-profile timer migrates once into a host repeat task. An 0.8.1
timer already converted to a task remains that task. Oldest deadlines get priority
so short repeat tasks cannot starve countdowns. The AUTO MESSAGES section has a master
switch, separate host/client profiles selected from session identity, allow-solo switch, per-player cooldown, newcomer
welcome switch, custom welcome text and welcome delay. Defaults: enabled, all roles,
solo allowed, 5s cooldown, welcomes off, 2s welcome delay. Existing peers are not
welcomed when enabling the feature or entering another lobby.
PING has independent task-building, stratagem, medium/large/giant-enemy and tactical
map switches. Ordinary ammo, grenades, stims and samples are excluded. Static
resources include TCS structures, LAS-98 and Bastion; native special-marker names
are resolved through the verified main-EXE lookup dispatched to by game.dll.
Replicated actor map pins
provide world XYZ coordinates; objective pins resolve their actual map name and
current-mission importance. Unknown targets without a verified name are skipped.
New self and teammate marks are observed; first observations establish a baseline.
Resupply pods/boxes and the M-103 Supply FRV are included as stratagem equipment.
Empty ground and map pins are excluded; objective and extraction pins remain.
Call-ins/task actions share a switch; separate templates: {玩家名}召唤了{目标}, {玩家名}正在开始{目标}.
Manual equipment marks keep the mark template; {动作} resolves to 召唤, 开始 or 标记. Shared calls with ambiguous attribution say 小队.
Mission/extraction catalog: 220 current spottable resources (184 specific, 36 generic task widgets).
Includes radar, broadcast, research, SEAF, fuel/data/ICBM, faction sites and mission carry items.
Generic location/terminal names use verified unit names; empty terrain remains excluded.
Specific native names take priority; map objective names/importance remain dynamic.
The exact old stock category-only template is upgraded to include {目标}.
Custom templates remain unchanged. A generic native location label does not
identify a specific building; objective map pins provide the actual task name.
Templates: {类别}, {目标}, {触发者}, {位置}; objective pins add {任务名} and
{任务类型} (primary, prerequisite, optional, tactical). Optional player short-label/colour
prefixes identify the triggerer; the actual network sender remains the local player.
The automatic-message minimum interval is tracked separately for each trigger
player. Their welcomes and pings share their timer; another player is independent.
Tasks and addon sends without a trigger use the local-player timer. Default 5s,
0 disables the limit. Multiple newcomers each retain their own pending welcome.
Player placeholders work in welcome/ping/task/addon messages: {玩家名} (name),
{缩写} (HUD label, e.g. A2), {编号} (actual squad slot, e.g. 2). {名字} and
{触发者} alias the name. Missing profile: 队友 / 队友 / ?. Unknown tokens remain literal.
HD2AutoChatAPI keeps the v2 handshake and adds revision 3 capabilities for independent
sends, detached role settings snapshots, and bounded drawing helpers. The separately
packaged Interface Demo registers a manual example tab; it does not subscribe to live
events or send on load. The release ZIP includes plugin-author guides under Docs/.
Settings persist in:

  %LOCALAPPDATA%\CowboyBingus\Helldivers2\AutoChat\tasks.txt
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\AutoChat\settings.txt
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\AutoChat\panel-position.txt

Files / 文件位置
  log      %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\AutoChat.log
  status   %LOCALAPPDATA%\CowboyBingus\Helldivers2\AutoChat\AutoChat-STATUS.txt
  settings %LOCALAPPDATA%\CowboyBingus\Helldivers2\AutoChat\tasks.txt

简体中文
-------
**不打开聊天栏**即可把一条聊天发给小队，键鼠不会被夺走。无按键菜单时游戏内按 **K** 呼出面板。
Mod Bindings Menu 就绪后，在按键设置页的 **Mods → AutoChat** 中给“Toggle AutoChat panel”指定按键；该动作注册后取代 K。菜单按其原生游戏键位设置保存改键；首次注册没有默认键，需要手动指定。

为什么能不发聊天栏就发聊天：聊天框做四件事——夺取键鼠、画框、收集按键、调发送。
"被卡在聊天栏"是前两件。本模组只要最后一件：聊天框自己用的那个聊天对象和那个发送
函数。所以没有框，也没有输入锁。

面板（默认快捷键 K；Mod Bindings Menu 动作注册后由菜单改键）
  - 沿用 Armory Forge 的 1000×990 框架、盾形标识、双栏、标签与控件
  - 字体先校验游戏资源已加载；提高字号与对比度，长文字省略，不再缩成6像素
  - 打开时解除鼠标锁定以便点击；关闭时把光标与裁剪矩形**原样**归还
  - 打开面板时屏蔽游戏键鼠，包括 Esc、O；关闭、失焦、异常和退出时归还输入
  - 拖动顶部条移动窗口；Ctrl +/- 缩放，Ctrl+0 复位；按钮松开时激活
  - 设置 → 添加定时任务：事件名称、定时类型、时间、发送消息均可自定义
  - 支持重复间隔、一次倒计时（5–86400 秒）和每天时刻（HH:MM，本机时间）
  - 中文可在字段内使用系统输入法直输，也可 Ctrl+V 粘贴；Enter 确认，Esc 取消
  - 填写完成后还须点击“添加任务”，任务才会保存并进入命名预设
  - 可添加任意数量的任务；单项字段和任务文件仍受明确大小限制

任务按真实时间计时，仅在游戏运行时执行。倒计时保存截止时刻；重启后到期任务尝试一次。
聊天未就绪、身份未知或角色条件不满足时，任务保持等待，不会直接消耗一次倒计时；任务不受事件冷却限制。
最早到期的任务优先，避免短周期任务一直占用发送机会。
自动消息：总开关、主机/客机独立配置并按当前会话身份启用、无人房间允许发送、标记/召唤提醒间隔、新人欢迎及自定义欢迎语/延迟；输出仍可选小队公屏或仅自己可见。旧快捷定时只在升级时转为普通重复任务，不再单独显示或发送。
默认允许主客机及单人发送，冷却5秒，新人欢迎关闭，欢迎延迟2秒；启用时不欢迎已有队友。
标记消息：任务建筑、战备提示、中型/大型/巨型敌人、地图标记分别开关；不再提示普通弹药、针剂、手雷、样本。
静态资源包含 TCS、LAS-98激光大炮、堡垒坦克、重新补给和M-103补给车；特殊标记优先读取游戏本地化名称（需校验当前DLL）。
本人和队友的新标记均可触发；本人标记使用本人的事件间隔，定时任务不受该间隔限制。
目录外的特殊目标要求游戏提供特殊类型与可读名称，名称未加载会在标记有效期内重试。
地图图钉读取实际同步状态；任务图钉使用游戏地图名称，支持“获取发射代码”等主线前置目标。
{目标}/{任务名}显示名称，{任务类型}读取当局主线、前置、支线或战术属性，不按名字猜；{位置}为世界XYZ。
普通地面空点和地图空白点不发消息；地图任务与撤离区保留。
战备召唤/任务执行共用开关、分别自定义消息；默认 {玩家名}召唤了{目标} 或 {玩家名}正在开始{目标}。
{动作} 按事件显示“召唤”“开始”或“标记”；共享战备无法确认触发者时显示“小队”。任务/撤离目录220个资源：184个具体名称、36个通用任务交互物。
包含雷达、广播、科研、SEAF、燃料/数据/导弹和各阵营设施；泛地点/终端使用已核实资源名。
任务携带物归任务建筑开关；普通物资与空地不发，不按最近坐标猜任务。
游戏只返回“特殊地点”且无目标ID时使用原标签；地图任务图钉使用具体任务名。
默认标记功能关闭，开启后响应本人和队友的新标记；消息支持 {类别}/{目标}/{触发者}/{位置}。
地图任务另支持 {任务名}/{任务类型}，变量提示在“标记消息”面板显示。旧默认模板自动加入 {目标}；其他自定义模板保留。
可开启真实队友缩写和队色前缀；实际聊天发件人仍为运行本模组的玩家，不冒用其他玩家身份。
标记、召唤和执行事件间隔按触发玩家分别计算：A不占用B/C；冷却中的新事件直接丢弃，不排队补发。默认5秒，0为不限制。
同时加入的新人各有独立欢迎队列，逐条发送；欢迎和定时任务忽略且不会延长事件间隔。不指定触发者的扩展发送使用本机玩家间隔。
欢迎、标记、定时任务与扩展消息支持 {玩家名}/{缩写}/{编号}；{名字}/{触发者}也是名字。
例如：欢迎 {玩家名}（{缩写}，{编号}号）加入小队！ 数据缺失时显示“队友/队友/?”，不猜编号。
其他模组可通过 HD2AutoChatAPI v2 注册显示名菜单、按钮与可选事件回调。revision 3
保留旧握手，并新增独立发送策略、当前角色设置副本和边界受限的绘图接口；独立发送仍由宿主检查会话、身份与原生发送入口。
独立接口示例包注册“接口示例”，提供手动发送；加载和绘制时不发送，也不订阅实时事件。
主包 ZIP 的 `Docs/` 目录包含插件 API 与接口示例指南。
设置保存在 `AutoChat\tasks.txt`；旧版已启用的单计时器迁移成可见任务。

按 K 呼出；退出输入后再按 K，或点右上角 X 关闭。
本版本尚未实机验收，离线布局预览不是游戏截图。
