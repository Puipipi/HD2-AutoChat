AutoChat / 自动聊天  v0.1.0  —— READ-ONLY PROBE

English
-------
This build changes NOTHING in the game. It reads, checks, and writes a log.
Its whole job is to answer one question before any chat feature is written:

    Do the recorded offsets still describe this game.dll?

What it checks
--------------
Five machine-code prefixes, from the third-party mod
mods/cowboybingus/better_lobby_management:

    game.dll+0x1097560   the chat send function
    game.dll+0x0bde430   the RPC send
    game.dll+0x186025d   the chat box's own call site
    game.dll+0x0beb103   the chat message RPC construction
    game.dll+0x1097a7c   the chat history reader

If every one matches, it then reads (never writes):
  - the network context pointer at game.dll+0x347cef0
  - the peer count at context+0x16390
  - the chat flag byte at context+0xC418   (raw value, reported not obeyed)
  - the chat history ring at context+0xC418+0x9590 / +0x9594

If a signature does not match, it says WHICH ONE and goes dormant. No offset
from this file is used after a mismatch.

Why a chat can be sent without opening the chat box
---------------------------------------------------
The game's chat box seizes the keyboard and mouse, draws a box, collects keys,
and then calls the send function. Being stuck in the chat box is the first two
steps. A mod only needs the last one: the chat object and the send function.
That is how the third-party mod above already sends squad messages.

Where the files are / 文件位置
  log     %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\AutoChat.log
  status  %LOCALAPPDATA%\CowboyBingus\Helldivers2\AutoChat\AutoChat-STATUS.txt

How to use it / 怎么用
  1. Enable and deploy. Start the game normally.
  2. Play for a minute. The log records one observation at boot and then only
     when the game's own values change, plus one heartbeat every ~30s.
  3. Send back AutoChat.log and AutoChat-STATUS.txt.

  The log is only evidence. Loading successfully proves nothing about chat.
  This build does not send any message and does not prove it could.

简体中文
-------
本版本不改变游戏任何行为，只读取、校验、写日志。它只回答一个问题：
**记录的偏移现在还描述这版 game.dll 吗？**

校验：5 段机器码前缀（发送函数、RPC 发送、聊天框调用点、聊天消息 RPC、
聊天历史读取），全部取自第三方模组 better_lobby_management 的源码记录。

随后只读地观测：网络上下文指针、会话人数、聊天开关字节（记原始值，不照
规则办事）、聊天历史环形缓冲的下标与行数。

任何一段签名对不上，日志会指明**是哪一段**，然后整局停手；对不上之后
本文件里的任何偏移都不会被使用。

为什么能不发聊天栏就发聊天：聊天框做四件事——夺取键鼠、画框、收集按键、
调发送。"被卡在聊天栏"是前两件。只要后一件就够了。

日志里只有证据。加载成功不证明任何聊天功能可用；本版本也不发送任何消息。
