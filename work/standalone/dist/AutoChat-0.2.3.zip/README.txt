AutoChat / 自动聊天  v0.2.3  —— SEND CAPABLE

English
-------
Sends a chat line to your squad WITHOUT opening the chat box, so your keyboard
and mouse are never taken away. This is why the mod exists: being stuck in the
chat box is caused by the box seizing input, and the box is not needed to send.

Before anything is sent, five machine-code signatures are checked against the
running game.dll. If any one of them does not match, the mod goes dormant and
says which one changed: an unverified address is an arbitrary address, and
calling it is how a mod takes the game down.

How to send
-----------
Put a line of text into this file (created for you):

  %LOCALAPPDATA%\CowboyBingus\Helldivers2\AutoChat\trigger.txt

The first non-empty line is sent once, then the file is cleared. To send the
same text again, write it again. While the file contains the word

  inspect

the mod does not send anything; it instead dumps every readable text run inside
the chat object into the log, so on-screen chat can be confirmed without a second
player being present.

You must be in a squad with at least one other player: the mod refuses to send
into an empty session, and says so by name.

Where the files are / 文件位置
  log     %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\AutoChat.log
  status  %LOCALAPPDATA%\CowboyBingus\Helldivers2\AutoChat\AutoChat-STATUS.txt
  trigger %LOCALAPPDATA%\CowboyBingus\Helldivers2\AutoChat\trigger.txt

What this build does NOT do
---------------------------
It does not patch game memory: no write primitive is declared and the build
refuses to package if one appears. It does not open, draw, or take input for any
UI. It cannot send if the game's own chat flag reads as off, and it will not send
if the signature check failed -- check the log for which.

简体中文
-------
**不打开聊天栏**就把一条聊天发给小队——键鼠从头到尾不会被夺走。"卡在聊天栏"
是聊天框抢输入造成的，而发消息根本不需要那个框。

发送之前会先校验 5 段机器码签名。任何一段对不上就整局停手，并写明是哪一段
变了：没验证过的地址就是任意地址，调用它就是让模组把游戏带崩。

怎么发：把一行文字写进 `AutoChat\trigger.txt`，第一行非空内容会被发一次然后
清空；要再发一遍就再写一次。写 `inspect` 则不发送，而是把聊天对象里所有可读
文本段倾倒进日志——这样不用第二个玩家也能确认聊天确实在动。

必须在至少还有一名其他玩家的小队里；空会话会被拒绝并写明原因。

本版本不写游戏内存（没有声明任何写原语，构建时出现就会拒绝打包），不画界面、
不夺取任何输入。游戏自己的聊天开关读出来是关的时候不会发。
